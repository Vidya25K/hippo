<?php


if (isset($_POST['submit']))
{
   myfnc();
}
function myfnc()
{
    
 $curl = curl_init();
 curl_setopt_array($curl, array(
   CURLOPT_URL => "https://api.staging.myhippo.io/v1/herd/quote?auth_token=zcXbR1NoE0zoozyuqAa75s5gBATbeiUsbkGhvb5toGiNWUdDjIUkAU5XgDwCRTet&street=435%20Homer%20Ave&city=Palo%20Alto&state=CA&zip=94301&first_name=John&last_name=Gill&email=Test%40test.com&phone=7869885582&date_of_birth=05061979",
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_ENCODING => "",
   CURLOPT_MAXREDIRS => 10,
   CURLOPT_TIMEOUT => 0,
   CURLOPT_FOLLOWLOCATION => true,
   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
   CURLOPT_CUSTOMREQUEST => "GET",
  
   CURLOPT_HTTPHEADER => array(
     "Content-Type: application/json"
        ),
 ));
 $SR_login_Response = curl_exec($curl);
 curl_close($curl);
 
  $data = json_decode($SR_login_Response);
  
$quote_premium=$data->quote_premium;
echo "<script>alert('Quote Premium :$quote_premium')</script>";
}

?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <style>
         
            body {
    color: #000;
    overflow-x: hidden;
    height: 100%;
    
    
}
input,select,option{
    border:none !important;
    outline:0 !important;
   
    border-bottom:1px solid #353535 !important;
}

.card {
    padding: 30px 40px;
    margin-top: 60px;
    margin-bottom: 60px;
    border: none !important;
    box-shadow: 0 6px 12px 0 rgba(0, 0, 0, 0.2)
}

.blue-text {
    color: #00BCD4
}

.form-control-label {
    margin-bottom: 0
}

input,
textarea,
button {
    padding: 8px 15px;
    
    margin: 5px 0px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    font-size: 18px !important;
    font-weight: 300
}

input:focus,
textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #00BCD4;
    outline-width: 0;
    font-weight: 400
}

.btn-block {
    text-transform: uppercase;
    font-size: 15px !important;
    font-weight: 400;
    height: 43px;
    cursor: pointer
}

.btn-block:hover {
    color: #fff !important
}

button:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    outline-width: 0
}

button{
    border-radius:25px;
}
            
            </style>
</head>
<body>
<div class="container-fluid px-1 py-5 mx-auto">
    <div class="row d-flex justify-content-center">
        <div class="col-xl-7 col-lg-8 col-md-9 col-11 text-center">
            
            
            <div class="card">
                
                <form class="form-card" method="POST" >
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">FIRST NAME<span class="text-danger"> *</span></label> <input type="text"    > </div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">MIDDLE NAME<span class="text-danger"> </span></label> <input type="text"    > </div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">LAST NAME<span class="text-danger"> *</span></label> <input type="text"    > </div>

                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-8 flex-column d-flex"> <label class="form-control-label px-3">STREET ADDRESS<span class="text-danger"> *</span></label> <input type="text"    > </div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">UNIT<span class="text-danger"> *</span></label> <input type="text"    > </div>
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">CITY<span class="text-danger"> *</span></label> <input type="text"    ></div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">STATE<span class="text-danger"> *</span></label> 
                        <select name="city" style="padding-top: 25px;" >
                        <option value="DEFAULT">     </option>
                        <option value="AL">Alabama</option>
	                    <option value="AK">Alaska</option>
	                    <option value="AZ">Arizona</option>
	                    <option value="AR">Arkansas</option>
	                    <option value="CA">California</option>
	                    <option value="CO">Colorado</option>
	                    <option value="CT">Connecticut</option>
	                    <option value="DE">Delaware</option>
	                    <option value="DC">District Of Columbia</option>
	                    <option value="FL">Florida</option>
	                    <option value="GA">Georgia</option>
	                    <option value="HI">Hawaii</option>
	                    <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                        </select>
                    </div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">ZIP CODE<span class="text-danger"> *</span></label> <input type="text"  > </div>                    
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-12 flex-column d-flex"> <label class="form-control-label px-3">DARE OF BIRTH<span class="text-danger"> *</span></label> <input type="date"  > </div>
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-8 flex-column d-flex"> <label class="form-control-label px-3">PHONE NUMBER<span class="text-danger"> *</span></label> <input type="text"    > </div>
                        <div class="form-group col-sm-4 flex-column d-flex"> <label class="form-control-label px-3">EMAIL<span class="text-danger"> *</span></label> <input type="text"    > </div>
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="card"><div class="card-body"><p class="card-text">XYZ</p></div> </div>
                        <div class="card"><div class="card-body"><p class="card-text">XYZ</p></div> </div>
                        <div class="card"><div class="card-body"><p class="card-text">XYZ</p></div> </div>

                    </div>
                    
                    <div class="row justify-content-center">
                        <div class="form-group col-sm-6"> <button type="submit" name="submit" class="btn-block btn-success">SUBMIT</button> </div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>