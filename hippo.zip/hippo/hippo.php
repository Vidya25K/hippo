<?php
/**
* Plugin Name: Hippo
* Description: Plugin for assignment
* Version: 1.0
* Author: Vidya Koli
**/

add_filter( 'page_template', 'wpa3396_page_template' );
function wpa3396_page_template( $page_template )
{
    if ( is_page( 'Sample Page' ) ) {
        $page_template = dirname( __FILE__ ) . '/hippohtml.php';
    }
    return $page_template;
}